#include "hello.h"
#include <iostream>

void sayHello(){
	std::cout << "Hello SLAM" << std::endl;
}
